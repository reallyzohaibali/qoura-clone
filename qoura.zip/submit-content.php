<?php
/**
 * Content Submission Processor Engine
 * Handles explicit POST routing for newly engineered user content blocks.
 */
require_once 'config/database.php';
require_once 'auth.php';

// SECURITY FIX: previously trusted a hidden `user_id` field from the client,
// meaning anyone could edit the form and post as a different user. Always
// derive the user from the server-side session instead.
$currentUser = getLoggedInUser();
if (!$currentUser) {
    header("Location: login.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pdo = getDBConnection();

    // Sanitize incoming payload strings safely
    $contentType = $_POST['content_type'] ?? 'question';
    $userId      = (int)$currentUser['id'];
    $topicId     = intval($_POST['topic_id'] ?? 0);
    $contentBody = trim($_POST['content_body'] ?? '');

    // Prevent submission routing if empty fields are intercepted
    if (empty($contentBody) || $topicId === 0) {
        header("Location: index.php?error=missing_fields");
        exit;
    }

    // ---- Image upload handling (optional) ----
    $imageUrl = null;
    if (isset($_FILES['content_image']) && $_FILES['content_image']['error'] !== UPLOAD_ERR_NO_FILE) {
        $file = $_FILES['content_image'];

        if ($file['error'] !== UPLOAD_ERR_OK) {
            header("Location: index.php?error=upload_failed");
            exit;
        }

        // Cap at 3MB
        if ($file['size'] > 3 * 1024 * 1024) {
            header("Location: index.php?error=file_too_large");
            exit;
        }

        // Strict mime-type verification (never trust the client-sent extension)
        $allowedTypes = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/gif'  => 'gif',
            'image/webp' => 'webp',
        ];
        $fileType = mime_content_type($file['tmp_name']);

        if (!isset($allowedTypes[$fileType])) {
            header("Location: index.php?error=invalid_file_type");
            exit;
        }

        $extension = $allowedTypes[$fileType];
        $newFileName = 'content_' . $userId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $extension;
        // Literal forward slash: stored in DB and used as a web URL, not a
        // filesystem path — avoids broken image paths on Windows/XAMPP.
        $uploadTarget = 'uploads/' . $newFileName;

        if (!move_uploaded_file($file['tmp_name'], $uploadTarget)) {
            header("Location: index.php?error=move_file_failed");
            exit;
        }

        $imageUrl = $uploadTarget;
    }

    try {
        if ($contentType === 'question') {
            // Write to the questions table
            $sql = "INSERT INTO questions (user_id, topic_id, title, image_url) VALUES (:user_id, :topic_id, :title, :image_url)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':user_id'   => $userId,
                ':topic_id'  => $topicId,
                ':title'     => $contentBody,
                ':image_url' => $imageUrl
            ]);
        } else {
            // Write to the posts table
            $sql = "INSERT INTO posts (user_id, topic_id, content, image_url) VALUES (:user_id, :topic_id, :content, :image_url)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':user_id'   => $userId,
                ':topic_id'  => $topicId,
                ':content'   => $contentBody,
                ':image_url' => $imageUrl
            ]);
        }

        // Send them back to refresh the main timeline upon successful execution
        header("Location: index.php?success=1");
        exit;

    } catch (PDOException $e) {
        error_log("Submission Processing Failure: " . $e->getMessage());
        header("Location: index.php?error=database_failure");
        exit;
    }
} else {
    // Redirect if accessed directly via browser URL bar instead of form button click
    header("Location: index.php");
    exit;
}
