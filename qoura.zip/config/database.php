<?php

// Database Connection Module

function getDBConnection() {
    // XAMPP / MySQL configuration
    $driver = 'mysql';

    try {
        if ($driver === 'mysql') {
            // Default XAMPP MySQL settings: host 127.0.0.1, user root, no password.
            // If you set a root password in XAMPP's MySQL config, put it in $pass below.
            $host = '127.0.0.1';
            $port = '3306';
            $db   = 'quora_db';
            $user = 'root';
            $pass = '';
            $dsn = "mysql:host=$host;port=$port;dbname=$db;charset=utf8mb4";
        } else {
            $host = 'localhost';
            $port = '5432';
            $db   = 'quora_db';
            $user = 'quora';
            $pass = '090090800908';
            $dsn = "pgsql:host=$host;port=$port;dbname=$db;";
        }

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        return new PDO($dsn, $user, $pass, $options);

    } catch (PDOException $e) {
        die("Database connection failed: " . $e->getMessage());
    }
}