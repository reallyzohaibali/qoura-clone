<?php
require_once 'config/database.php';
require_once 'auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: index.php");
    exit;
}

// BUG FIX: $currentUser was never defined in this file (it was only ever set
// in index.php). That undefined variable was always falsy, so every answer
// submission was redirected to login.php regardless of actual login state.
$currentUser = getLoggedInUser();

if (!$currentUser) {
    header("Location: login.php");
    exit;
}

$pdo = getDBConnection();

$questionId = (int)($_POST['question_id'] ?? 0);
$answerContent = trim($_POST['answer_content'] ?? '');

$userId = $currentUser['id'];

if ($questionId <= 0 || $answerContent === '') {
    header("Location: index.php?error=empty_answer");
    exit;
}

try {

    $stmt = $pdo->prepare("
        INSERT INTO answers
        (
            question_id,
            user_id,
            content
        )
        VALUES
        (
            :question_id,
            :user_id,
            :content
        )
    ");

    $stmt->execute([
        ':question_id' => $questionId,
        ':user_id' => $userId,
        ':content' => $answerContent
    ]);

    header("Location: index.php?success=answer_added");
    exit;

} catch (PDOException $e) {

    error_log($e->getMessage());

    header("Location: index.php?error=db_error");
    exit;
}