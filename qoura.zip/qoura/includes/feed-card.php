<div class="card-quora p-3 mb-3">
    <!-- 1. Card Header: Author Profile Signature -->
    <div class="d-flex justify-content-between align-items-start">
        <div class="d-flex gap-2">
            <img src="<?= htmlspecialchars($item['profile_pic'] ?? 'uploads/default.png') ?>" class="profile-pic-md" alt="Author Profile" style="width:40px; height:40px; object-fit:cover; border-radius:50%;">
            <div>
                <div class="fw-bold fs-7">
                    <?= htmlspecialchars($item['author_name']) ?> 
                    <span class="text-muted-custom fw-normal">· <span class="badge bg-light text-dark border font-monospace fs-9"><?= htmlspecialchars($item['topic_name']) ?></span></span>
                </div>
                <div class="text-muted-custom fs-8">
                    <?= htmlspecialchars($item['author_box']) ?> · <?= date('M d, Y', strtotime($item['created_at'])) ?>
                </div>
            </div>
        </div>
        <!-- Right Action Triggers Matrix -->
        <?php if ($currentUser && $currentUser['id'] == $item['author_id']): ?>
            <div class="d-flex gap-1">
                <?php if ($item['type'] === 'question'): ?>
                    <button type="button" class="btn btn-sm text-secondary p-1" data-bs-toggle="collapse" data-bs-target="#editQuest<?= $item['item_id'] ?>"><i class="bi bi-pencil-square"></i></button>
                <?php else: ?>
                    <button type="button" class="btn btn-sm text-secondary p-1" data-bs-toggle="collapse" data-bs-target="#editPost<?= $item['item_id'] ?>"><i class="bi bi-pencil-square"></i></button>
                <?php endif; ?>
                <a href="delete.php?id=<?= $item['item_id'] ?>&type=<?= $item['type'] ?>" class="btn btn-sm text-danger p-1" onclick="return confirm('Delete permanently?')"><i class="bi bi-trash3-fill"></i></a>
            </div>
        <?php else: ?>
            <button type="button" class="btn-close fs-8" aria-label="Close"></button>
        <?php endif; ?>
    </div>

    <!-- 2. Main Content Layout Body Context Wrapper -->
    <?php if ($item['type'] === 'question'): ?>
        <div class="post-title fw-bold fs-5 my-2 text-dark" style="font-family: serif; line-height: 1.3;">
            <?= htmlspecialchars($item['question_title']) ?>
        </div>
        
        <!-- Render Attached Question Illustration Graphic (If uploaded) -->
        <?php if (!empty($item['image_url'])): ?>
            <div class="my-2 text-center">
                <img src="<?= htmlspecialchars($item['image_url']) ?>" class="img-fluid rounded border" alt="Question Graphic Attachment" style="max-height: 350px; width: 100%; object-fit: cover;">
            </div>
        <?php endif; ?>

        <!-- Inline Question Header Editing Interface Layout Form Row -->
        <div class="collapse my-2" id="editQuest<?= $item['item_id'] ?>">
            <form action="edit-question.php" method="POST" class="d-flex gap-2">
                <input type="hidden" name="question_id" value="<?= $item['item_id'] ?>">
                <input type="text" name="question_title" class="form-control form-control-sm" value="<?= htmlspecialchars($item['question_title']) ?>" required>
                <button type="submit" class="btn btn-sm btn-success">Save</button>
            </form>
        </div>
    <?php else: ?>
        <!-- Text Content Area (Rendered exclusively for raw timeline Posts) -->
        <div class="fs-7 text-secondary mb-3 mt-2" style="line-height: 1.6;">
            <?= nl2br(htmlspecialchars($item['content'])) ?>
        </div>

        <!-- Render Attached Post Image (If uploaded) -->
        <?php if (!empty($item['image_url'])): ?>
            <div class="my-2 text-center">
                <img src="<?= htmlspecialchars($item['image_url']) ?>" class="img-fluid rounded border" alt="Post Image Attachment" style="max-height: 350px; width: 100%; object-fit: cover;">
            </div>
        <?php endif; ?>
        
        <!-- Inline Post Text Editing Interface Layout Form Row -->
        <div class="collapse my-2" id="editPost<?= $item['item_id'] ?>">
            <form action="edit-post.php" method="POST" class="d-flex flex-column gap-2">
                <input type="hidden" name="post_id" value="<?= $item['item_id'] ?>">
                <textarea name="post_content" class="form-control form-control-sm" rows="3" required><?= htmlspecialchars($item['content']) ?></textarea>
                <button type="submit" class="btn btn-sm btn-success align-self-end px-3">Save</button>
            </form>
        </div>
    <?php endif; ?>

    <!-- 3. Footer Control Bar Layout Menu Indicators -->
    <div class="d-flex justify-content-between align-items-center mt-2">
        <div class="d-flex gap-1 align-items-center">
            
            <!-- Dual Voting Engine Segment Controllers -->
            <div class="upvote-group d-flex align-items-center bg-light border rounded-pill overflow-hidden">
                <a href="vote.php?item_id=<?= $item['item_id'] ?>&type=<?= $item['type'] ?>&action=up" class="btn btn-sm btn-upvote text-decoration-none d-flex align-items-center px-3 py-1 border-0" style="color: #2e69ff; font-weight: 500; font-size: 13px;">
                    <i class="bi bi-arrow-up-circle-fill me-1"></i> Upvote 
                    <span class="fw-bold text-dark ms-2"><?= intval($item['vote_score']) ?></span>
                </a>
                <a href="vote.php?item_id=<?= $item['item_id'] ?>&type=<?= $item['type'] ?>&action=down" class="btn btn-sm btn-downvote text-decoration-none px-2 py-1 border-start border-0" style="color: #636466;">
                    <i class="bi bi-arrow-down-circle"></i>
                </a>
            </div>
            
            <?php if ($item['type'] === 'question' && $currentUser): ?>
                <button type="button" class="btn btn-light btn-sm border rounded-pill px-3 ms-2 text-muted-custom fw-semibold" 
                        data-bs-toggle="collapse" 
                        data-bs-target="#answerForm<?= $item['item_id'] ?>" 
                        style="font-size: 13px;">
                    <i class="bi bi-pencil-square me-1"></i> Answer
                </button>
            <?php endif; ?>
            
            <button type="button" class="btn-action-icon ms-2" title="Comment"><i class="bi bi-chat-text"></i></button>
            <button type="button" class="btn-action-icon" title="Share"><i class="bi bi-repeat"></i></button>
        </div>
        <button type="button" class="btn-action-icon" title="More options"><i class="bi bi-three-dots"></i></button>
    </div>

    <!-- 4. Dynamic Inline Writing Input Panel Form Submissions Target -->
    <?php if ($item['type'] === 'question' && $currentUser): ?>
        <div class="collapse mt-3" id="answerForm<?= $item['item_id'] ?>">
            <form action="submit-answer.php" method="POST" class="border-top pt-2">
                <input type="hidden" name="question_id" value="<?= $item['item_id'] ?>">
                <div class="mb-2">
                    <textarea class="form-control fs-7" name="answer_content" rows="3" placeholder="Write your professional response here..." required></textarea>
                </div>
                <div class="d-flex justify-content-end">
                    <button type="submit" class="btn btn-sm btn-danger rounded-pill px-3" style="background-color: #b92b27; border: none;">Submit Answer</button>
                </div>
            </form>
        </div>
    <?php endif; ?>

    <!-- 5. DYNAMIC ANSWERS LOOP: Pulls Real User Accounts Database Identity Profiles -->
    <!-- 5. REPAIRED ANSWERS MATRIX: Pulls Real User Accounts Identity Profiles -->
    <?php if ($item['type'] === 'question'): ?>
        <div class="mt-3 border-top pt-2 replies-matrix-container">
            <?php if (!empty($item['answers']) && is_array($item['answers'])): ?>
                
                <div class="text-muted-custom fs-8 fw-bold text-uppercase mb-2 tracking-wide" style="font-size: 11px; color: #636466;">
                    <i class="bi bi-chat-left-quote me-1"></i> Public Answers (<?= count($item['answers']) ?>)
                </div>

                <?php foreach ($item['answers'] as $singleAnswer): ?>
                    <div class="bg-light p-2 rounded-3 mb-2 border-start border-3 border-primary shadow-sm" style="background-color: #f8fafc !important;">
                        
                        <!-- Header row inside the loop - mapping EXACT respondent data fields -->
                        <div class="d-flex align-items-center gap-2 mb-1">
                            <img src="<?= htmlspecialchars($singleAnswer['profile_pic'] ?? 'uploads/default.png') ?>" 
                                 class="rounded-circle border" 
                                 style="width:26px; height:26px; object-fit:cover;" 
                                 alt="Respondent Avatar">
                            
                            <span class="fs-7 fw-bold text-dark" style="font-size: 13px;">
                                <?= htmlspecialchars($singleAnswer['author_name']) ?>
                            </span>
                            
                            <span class="fs-8 text-muted" style="font-size: 11px; color: #636466;">
                                • <?= htmlspecialchars($singleAnswer['author_box'] ?? 'Platform Contributor') ?>
                            </span>
                        </div>

                        <!-- Content body row inside the loop -->
                        <div class="fs-7 text-secondary ps-4 style-response-body" style="line-height: 1.5; color: #393a3c; font-size: 13px;">
                            <?= nl2br(htmlspecialchars($singleAnswer['content'])) ?>
                        </div>

                    </div>
                <?php endforeach; ?>

            <?php else: ?>
                <!-- Clean empty state view layout -->
                <div class="text-muted fs-7 ps-2 pb-2" style="font-style: italic; font-size: 13px; color: #939598;">
                    <i class="bi bi-chat-dots me-1"></i> No answers yet. Be the first to answer this question!
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>