<?php
require_once 'auth.php';

function getHomeFeed($pdo, $topicSlug = null, $searchQuery = null) {
    $feedItems = [];
    $postParams = [];
    $questParams = [];
    $postWhere = [];
    $questWhere = [];

    // Separate bind parameter arrays to avoid cross-contamination crashes
    if ($topicSlug !== null) {
        $postWhere[] = "t.slug = :topic_slug";
        $questWhere[] = "t.slug = :topic_slug";
        
        $postParams[':topic_slug'] = $topicSlug;
        $questParams[':topic_slug'] = $topicSlug;
    }

    if ($searchQuery !== null && trim($searchQuery) !== '') {
        $term = "%" . trim($searchQuery) . "%";
        $postWhere[] = "(p.content LIKE :search OR u.name LIKE :search)";
        $questWhere[] = "(q.title LIKE :search OR u.name LIKE :search)";
        
        $postParams[':search'] = $term;
        $questParams[':search'] = $term;
    }

    $postWhereStr = !empty($postWhere) ? " WHERE " . implode(" AND ", $postWhere) : "";
    $questWhereStr = !empty($questWhere) ? " WHERE " . implode(" AND ", $questWhere) : "";

    try {
        // 1. Posts Query Pipeline
        $postSql = "SELECT p.id as item_id, 'post' as type, p.content, p.image_url, p.created_at, p.user_id as author_id,
                           u.name as author_name, u.bio as author_box, u.profile_pic, t.name as topic_name,
                           (SELECT COUNT(*) FROM upvotes WHERE item_id = p.id AND item_type = 'post') as vote_score
                    FROM posts p 
                    JOIN users u ON p.user_id = u.id 
                    JOIN topics t ON p.topic_id = t.id
                    {$postWhereStr}";
        $stmt = $pdo->prepare($postSql); 
        $stmt->execute($postParams);
        $posts = $stmt->fetchAll();

        // 2. Questions Query Pipeline (Added q.image_url column)
        $questSql = "SELECT q.id as item_id, 'question' as type, q.title as question_title, q.image_url, q.created_at, q.user_id as author_id,
                            u.name as author_name, u.bio as author_box, u.profile_pic, t.name as topic_name,
                            (SELECT COUNT(*) FROM upvotes WHERE item_id = q.id AND item_type = 'question') as vote_score
                     FROM questions q 
                     JOIN users u ON q.user_id = u.id 
                     JOIN topics t ON q.topic_id = t.id
                     {$questWhereStr}";
        $stmt = $pdo->prepare($questSql); 
        $stmt->execute($questParams);
        $questions = $stmt->fetchAll();

        // 3. Robust Answers Hydration Loop (Using clean parameter isolation)
        foreach ($questions as &$q) {
            $q['answers'] = []; // Initialize as an empty array to prevent layout errors
            
            $ansSql = "SELECT a.id, a.content, a.created_at, u.name as author_name, u.bio as author_box, u.profile_pic 
                       FROM answers a 
                       JOIN users u ON a.user_id = u.id 
                       WHERE a.question_id = ? 
                       ORDER BY a.created_at ASC";
            
            $ansStmt = $pdo->prepare($ansSql); 
            $ansStmt->execute([$q['item_id']]);
            $q['answers'] = $ansStmt->fetchAll();
        }
        unset($q); // Clean up the reference variable pointer

        // Combine feeds and sort by creation date
        $feedItems = array_merge($posts, $questions);
        usort($feedItems, function($a, $b) { 
            return strtotime($b['created_at']) <=> strtotime($a['created_at']); 
        });

    } catch (PDOException $e) { 
        error_log("Feed Service Database Error: " . $e->getMessage()); 
    }
    
    return $feedItems;
}